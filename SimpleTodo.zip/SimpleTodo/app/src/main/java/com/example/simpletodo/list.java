package com.example.simpletodo;

public class list<T> {
}
